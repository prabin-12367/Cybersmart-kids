from modules.education import show_lessons

def main():
    print("Welcome to CyberSmart Kids!")
    show_lessons()

if __name__ == "__main__":
    main()