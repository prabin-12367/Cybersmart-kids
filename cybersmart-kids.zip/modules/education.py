def show_lessons():
    lessons = [
        "1. What is the Internet?",
        "2. Safe Passwords",
        "3. Do not share personal info",
        "4. Recognize online scams",
        "5. What to do if you see something bad"
    ]
    for lesson in lessons:
        print(lesson)