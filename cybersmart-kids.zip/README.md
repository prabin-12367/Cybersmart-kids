# CyberSmart Kids
An interactive Python project to teach kids about cybersecurity basics in a fun and simple way.